#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Andrey
#
# Created:     29.03.2022
# Copyright:   (c) Andrey 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import telebot
from extensions import APIException, CurrConvertor
from config import TOKEN, keys

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start', 'help'])
def help(message: telebot.types.Message):
    text = ''
    if message.text == '/start':
        text = 'Добро пожаловать в конвертер курсов валют!\n'
    text += 'Чтобы начать работу, введите команду боту в формате: \n <название \
конвертируемой валюты> <в какую валюту конвертировать> <количество конвертируемой \
валюты (дробная часть отделяется точкой)>\nУвидеть список доступных \
валют: /values \nПример использования команды: "доллар рубль 12.6"\n\
Просмотреть справку еще раз: /help'
    bot.send_message(message.chat.id, text)

@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
	text = 'Доступные валюты:'
	for key in keys.keys():
        	text = '\n'.join((text, key))
	bot.reply_to(message, text)

@bot.message_handler(content_types=['text'])
def converter(message: telebot.types.Message):
    try:
        values = message.text.split(' ')
        if len(values) != 3:
            raise APIException('Для конвертации введите три параметра!')
        quote, base, amount = values
        total_base = CurrConvertor.get_price(quote, base, amount)
    except APIException as err:
        bot.reply_to(message, f'Неверная команда: \n{err}')
    except Exception as err:
        bot.reply_to(message, f'Неизвестная ошибка :( \n{err}')
    else:
        text = f'Цена {amount} {quote} = {total_base} {base} '
        bot.send_message(message.chat.id, text)
bot.polling(none_stop=True)