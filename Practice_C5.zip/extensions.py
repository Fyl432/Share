#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Andrey
#
# Created:     28.03.2022
# Copyright:   (c) Andrey 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import requests
import json
from config import keys

class APIException(Exception):
    pass

class CurrConvertor:
    @staticmethod
    def get_price(quote:str, base:str, amount:str):
        if  quote == base:
            raise APIException(f'Вы указали две одинаковые валюты "{base}"!')
        try:
            quote_ticker = keys[quote]
        except KeyError:
            raise APIException(f'Неизвестная валюта "{quote}". \nПолучить список поддерживаемых валют: /values')
        try:
            base_ticker = keys[base]
        except KeyError:
            raise APIException(f'Неизвестная валюта "{base}". \nПолучить список поддерживаемых валют: /values')
        try:
            amount = float(amount)
        except ValueError:
            errtext= f'Количество должно быть числом, а не "{amount}"!'
            if ',' in amount: errtext += '\nДробная часть отделяется запятой!'
            raise APIException(errtext)

        r = requests.get(f'https://min-api.cryptocompare.com/data/price?fsym={quote_ticker}&tsyms={base_ticker}')
        total_base = json.loads(r.content)[keys[base]]
        total_base *= amount
        return total_base
