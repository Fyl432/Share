#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Andrey
#
# Created:     28.03.2022
# Copyright:   (c) Andrey 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------
TOKEN = "5107210179:AAENILCrHIAG8nqG4NuDyhga_eNM5CkNoLU"
keys = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB',
    'англ_фунт': 'GBP',
    'юань': 'CNY',
    'биткойн':'BTC',
    'эфириум': 'ETH'
}